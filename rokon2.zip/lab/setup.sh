#!/bin/bash

# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

# Initialize uv project
uv init

# Install Python packages
uv add numpy matplotlib scikit-image torch scikit-learn pandas opencv-python
